# Ba137_hyperfine_hamiltonian_solver

Hyperfine Hamiltonians, transition spectra, and transition strengths for $^{137}Ba^{+}$ $(D_{5/2}, S_{1/2}, P_{3/2})$.

## Installation

```bash
pip install Ba137_hyperfine_hamiltonian_solver
```
